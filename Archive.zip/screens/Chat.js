import React from "react";
import { GiftedChat } from "react-native-gifted-chat";

export default function Chat(){
    return(
        <GiftedChat />
    )
}